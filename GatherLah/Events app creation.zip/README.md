
  # Events app creation

  This is a code bundle for Events app creation. The original project is available at https://www.figma.com/design/RjkICHgmPWkHyeYvRCBefb/Events-app-creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  